
<header id="top" class="vg-TopHeight">

    @include('partials/frontend/menu')
    @include('partials/frontend/banner')
  </header>