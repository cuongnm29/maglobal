@if(isset($setting))
        <section id="section-googlemap" class="page-area vg-section-image vg-color-2">
            <div class="wrapper">

                <div class="custom">
                    <div>{!!$setting->map!!}</div>
                </div>
            </div>
        </section>
        @endif