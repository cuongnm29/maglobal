@extends('layouts.frontend')
@section('content')
@include('partials.frontend.service')
@include('partials.frontend.gallery')
@include('partials.frontend.about')
@include('partials.frontend.map')
@include('partials.frontend.contact')
@endsection
