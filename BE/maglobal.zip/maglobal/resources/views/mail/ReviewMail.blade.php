@component('mail::message')
	# How do you like everything about our service?
    
	And Can you give us some reviews about the service so that we can improve in the process of serving? 

(note: you can get 5% off on next bill if you register member in the link below to get account number. 
So you should register member before, and get account number then come back this mail and enter account number into the field below)

@endcomponent
