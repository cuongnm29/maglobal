@component('mail::message')
# Welcome new member! 

First Name : {{$firstname}}

Last Name : {{$lastname}}

Email  : {{$email}}

Phone: {{$phone}}

Account number : {{$accountNumber}}


Have a nice day!

@endcomponent