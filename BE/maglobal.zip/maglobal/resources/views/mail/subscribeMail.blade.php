@component('mail::message')

   
	{!!$summary!!}
	   

@endcomponent
