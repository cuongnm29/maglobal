@component('mail::message')

# Hello! 

You are receving this email because we recevied a password reset request for account

{{$link}}

if you did not request a password reset, no further action is Request

Regards,

Expert Nails and Beauty Family

@endcomponent