<?php

return [
    'site_title' => 'Ma-Global',
];
